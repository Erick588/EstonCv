<?php
 include('security.php');

if(isset($_POST['registerbtn']))
{
   
    $institution = $_POST['institution'];
    $course = $_POST['course'];
    $grade = $_POST['grade'];
    $date = $_POST['date'];
    $date1 = $_POST['date1'];
    $body = $_POST['body'];
    $cert = $_POST['cert'];
    $title = $_POST['title']; 
    $lang = $_POST['lang'];
    $lang1 = $_POST['lang1'];
    $lang2 = $_POST['lang2'];
    $company = $_POST['company'];
    $position = $_POST['position'];
    $date1 = $_POST['date1'];
    $duties = $_POST['duties'];
    $linkedin = $_POST['linkedin'];
    $git = $_POST['git'];
    $userId = $_POST['user_id'];


$query = "INSERT INTO profile (user_id, institution, course, grade, date, body, cert, title, lang, lang1, lang2, company, position, 
    date1, duties, linkedin, git) VALUES 
('$userId','$institution','$course','$grade','$date','$body', '$cert','$title','$lang','$lang1','$lang2','$company','$position', '$date1', '$duties','$linkedin', '$git')";

$query_run = mysqli_query($connection, $query);

if($query_run)
{
 
  $_SESSION['success']= "Your Data is Updated";
header('location: index.php');
}
else{
  $_SESSION['status']= "Your Data is Not Updated";
  header('location: index.php');

}
}


if(isset($_POST['logout_btn']))
{
  session_destroy();
  unset($_SESSION['username']);
  header('location:../login.php');
}

?>


