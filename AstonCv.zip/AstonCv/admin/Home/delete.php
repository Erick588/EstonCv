<?php 
      
      include('security.php');

      if(isset($_POST['delete_btn']))
{
    $id = $_POST['delete_id'];
   
    $query_run =  mysqli_query($connection,"update user1 set status = 'Innactive' where id='$id'")or die(mysqli_error());
   if($query_run) {
        $_SESSION['success'] = "Profile Deleted Successfully";
        header('Location: register.php');
       
    }
    else 
    {
        $_SESSION['status'] = "Profile Not Deleted";
        header('Location: register.php');  
    }




}
if(isset($_POST['att_delete']))
{
    $id = $_POST['id'];
   
    $query_run =  mysqli_query($connection,"DELETE FROM attendance WHERE id='$id'")or die(mysqli_error());

    if ($query_run) {
        $_SESSION['success'] = "Record Deleted Successfully";
        header('location: attendance.php');
      } else {
        $_SESSION['status'] = "Record not Deleted";
        header('location: attendance.php');
      }
}

if(isset($_POST['diss_btn']))
{
    $id = $_POST['edit_id'];

    $query_run =  mysqli_query($connection,"DELETE FROM dismissal WHERE user_id= '$id'")or die(mysqli_error($connection));

    if ($query_run) {
        $_SESSION['success'] = "Record Deleted Successfully";
        header('location: dismissal.php');
      } else {
        $_SESSION['status'] = "Record not Deleted";
        header('location: dismissal.php');
      }
}

if(isset($_POST['delete_warn']))
{
    $id = $_POST['edit_id'];

    $query_run =  mysqli_query($connection,"DELETE FROM warnings WHERE id= '$id'")or die(mysqli_error($connection));

    if ($query_run) {
        $_SESSION['success'] = "Record Deleted Successfully";
        header('location: warnings.php');
      } else {
        $_SESSION['status'] = "Record not Deleted";
        header('location: warnings.php');
      }
}
if(isset($_POST['delete_ret']))
{
    $id = $_POST['id'];

    $query_run =  mysqli_query($connection,"DELETE FROM retirement WHERE id= '$id'")or die(mysqli_error($connection));

    if ($query_run) {
        $_SESSION['success'] = "Record Deleted Successfully";
        header('location: retirement.php');
      } else {
        $_SESSION['status'] = "Record not Deleted";
        header('location: retirement.php');
      }
}

if(isset($_POST['prom_delete']))
{
    $id = $_POST['rid'];

    $query_run =  mysqli_query($connection,"DELETE FROM promotions WHERE prom_id= '$id'")or die(mysqli_error($connection));

    if ($query_run) {
        $_SESSION['success'] = "Record Deleted Successfully";
        header('location: promotion.php');
      } else {
        $_SESSION['status'] = "Record not Deleted";
        header('location: promotion.php');
      }
}
?>