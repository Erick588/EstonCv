<?php 
      include('security.php');
      include('includes/header.php');
      include('includes/navbar.php');

?>


<div class="container-fluid">
    <!---Datatable example --->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
        <h5 class="m-0 font-weight-bold text-primary">Employee Profile
<button type="button" class="btn btn-primary" data-toggle="modal" onclick=" relocate_home()">
       Add Employee
</button>

<script>
function relocate_home()
{
     location.href = "new_employee.php";
} 
</script>
</h5>
</div>
<div class="card-body">

<?php
if(isset($_SESSION['success']) && $_SESSION['success']!='')
{
    echo '<h2>'.$_SESSION['success'].'</h2>';
    unset($_SESSION['success']);
}
if(isset($_SESSION['status']) && $_SESSION['status']!='')
{
    echo '<h2 class="bg-info">'.$_SESSION['status'].'</h2>';
    unset($_SESSION['status']);
}
?>
    
        <?php
        $connection= mysqli_connect('localhost', 'root', '', 'erp');
        $session =  $_SESSION['username'];
        $query="SELECT * FROM user1 WHERE email = '$session'";
        $query_run=mysqli_query($connection, $query);
        
        
        ?>
         <table  class="table  table-hover" id="table1">
							    
            <thead>
                <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>Details</th>
                    <th>Contacts</th>
                    <th>User Information</th>
                    <th>Edit</th>
                    <th>Delete</th>
                </tr>
            </thead>
<tbody>
<?php                  $i = 1;
                        if(mysqli_num_rows($query_run) > 0)        
                        {
                            while($row = mysqli_fetch_assoc($query_run))
                            {
                        ?>
                            <tr>
                                <td><?php  echo $i++ ?></td>
                                <td>
                                <?php  

                           
                                echo  $row['firstname']." ".$row['middlename']." ".$row['lastname'];
                                       ?>
                                       <br>
                                       <small class="text-muted hrsale-text-info-margin">
                                     <i>Shift:<?php  echo $row['shift']; ?><i></i></i></small><br>
                                    <small class="text-muted hrsale-text-info-margin">
                                   <i>Role:<?php  echo $row['usertype']; ?> <i></i>
                                    </i></small> 
                                       </td>
                                <td>
                                <?php  echo $row['department'];?>
                                       <br>
                                    <small class="text-muted hrsale-text-info-margin">
                                     <i>Designation:<?php  echo $row['designation']; ?></i></small><br>
                                    <small class="text-muted hrsale-text-info-margin">
                                   <i>Employee No#:<?php  echo $row['empcode']; ?> </i></small><br>
                                    <small class="text-muted hrsale-text-info-margin">
                                   <i>Employee type:<?php  echo $row['emptype']; ?> <i></i>
                                    </i>
                                    </small>
                                </td>
                                <td>
                                <i class="fas fa-envelope" data-toggle="tooltip" data-placement="top" title="" data-original-title="Username"></i>
                                <?php  echo $row['email']; ?><br/> 
                        
                                       <i class="fas fa-phone" data-toggle="tooltip" data-placement="top" title="" data-original-title="Username"></i>
                                <?php  echo $row['contact']; ?><br/>

                                <i class="fas fa-location-arrow" data-toggle="tooltip" data-placement="top" title="" data-original-title="Username"></i>
                                <?php  echo $row['address']; ?><br/> 

                                      
                                </td>
                                <td>
                                     <small class="text-muted hrsale-text-info-margin">
                                     <i>Disability Status:<?php  echo $row['distatus'];?></i></small><br>
                                    <small class="text-muted hrsale-text-info-margin">
                                     <i>Employment Date:<?php  echo $row['empdate'];?></i></small><br>
                                    <small class="text-muted hrsale-text-info-margin">
                                   <i>Gender:<?php  echo $row['sex']; ?> </i></small><br>
                                    <small class="text-muted hrsale-text-info-margin">
                                   <i>ID No#:<?php  echo $row['idno']; ?> <i></i>
                                    </i>
                                    </small> <br>
                                    <small class="text-muted hrsale-text-info-margin">
                                     <i>NHIF No.<?php  echo $row['nhif'];?></i></small>
                                       <br>
                                     <small class="text-muted hrsale-text-info-margin">
                                     <i>NSSF No.<?php  echo $row['nssf'];?></i></small>                              
                                <td>
                                    <form action="register_edit.php" method="post">
                                        <input type="hidden" name="edit_id" value="<?php echo $row['id']; ?>">
                                        <button type="submit" name="edit_btn" class="btn btn-primary"> <i class="fas fa-edit"></i></button>
                                    
                                    </form>
                                </td>
                                <td>
                                    <form action="delete.php" method="post">
                                        <input type="hidden" name="delete_id" value="<?php echo $row['id']; ?>">
                                        <button type="submit" name="delete_btn" class="btn btn-danger"><i class="fas fa-trash-alt danger"></i></i></button>
                                    </form>
                                </td>
                            </tr>
                        <?php
                            } 
                        }
                        else {
                            echo "No Record Found";
                        }
                        ?>
                    </tbody>

            
                </table>
               
            </div>
        </div>
        
            
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<script>
            $(document).ready(function() {
                $('#table1').DataTable();
            });
        </script>

<?php
 include('includes/scripts.php');
 include('includes/footer.php');
 
 ?>
