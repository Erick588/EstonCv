<?php 
      
      include('security.php');
      include('includes/header.php');
      include('includes/navbar.php');

?>
<div class="container-fluid">
    <!---Datatable example --->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Edit Admin Profile</h6>
    </div>
<div class="card-body">
<?php
$connection= mysqli_connect('localhost', 'root', '', 'erp');
if(isset($_POST['edit_btn']))
{
$id = $_POST['edit_id'];

$query = "SELECT *FROM user1 WHERE id= '$id'";
$query_run = mysqli_query($connection, $query);

foreach($query_run as $row)
{

    
  ?>
<form action="code.php" method="POST">
 <input type="hidden" name="edit_id" value="<?php echo $row['id'] ?>">
 <div class="form-group row">
                    <div class="col-sm-3">
                        <label for="inputFirstname">First name</label>
                        <input type="text" class="form-control" name="firstname" value="<?php echo $row['firstname']?>" placeholder="First name">
                    </div>
                    <div class="col-sm-3">
                        <label for="inputLastname">Other Names</label>
                        <input type="text" class="form-control" name="middlename" value="<?php echo $row['middlename']?>" placeholder="Last name">
                    </div>
                    <div class="col-sm-3">
                        <label for="inputLastname">Surname</label>
                        <input type="text" class="form-control" name="lastname" value="<?php echo $row['lastname']?>" placeholder="Last name">
                    </div>
                    <div class="col-sm-3">
                        <label for="inputLastname">Disabilty Status</label>
                        <div class="radio">
                      <label><input type="radio" name="distatus" value="Yes"checked>Yes</label>
                         </div>
                       <div class="radio">
                            <label><input type="radio" name="distatus"value="No">No</label>
                        </div>
                         
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-sm-3">
                        <label for="inputAddressLine1">Employee Number</label>
                        <input type="number" class="form-control" name="empcode" value="<?php echo $row['empcode']?>" placeholder="Employee Number">
                    </div>
                    <div class="col-sm-3">
                        <label for="inputAddressLine2">Id Number</label>
                        <input type="Number" class="form-control" name="idno"  value="<?php echo $row['idno']?>" placeholder="ID Number">
                    </div>
                    <div class="col-sm-3">
                        <label for="inputAddressLine2">Birth Date</label>
                        <input type="date" class="form-control"  value="<?php echo $row['birthdate']?>" name="birthdate">
                    </div>
                    <div class="col-sm-3">
                    <label for="inputAddressLine2">Sex</label>
                    <Select name="sex" class="form-control">
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                </select>
                    </div>
                </div>
                <div class="form-group row">
                <div class="col-sm-4">
                <label for="" class="control-label">Department*</label>
                      
                      <select class="custom-select" name="department"  value="" required id="monitor">
                  <option value="<?php echo $row['department']?>" ><?php echo $row['department']?></option>
                              
                             </select>
                             </div>
                 <div class="col-sm-4">
                <label for="" class="control-label">Division*</label>
                      
                 <select class="custom-select" name="division" required id="monitor">
                  <option value="" >NULL</option>
                  <option value="A" >A</option>
                  <option value="B" >B</option>               
                 </select>
                </div>
                             <div class="col-sm-4">
                <label for="" class="control-label">Section</label>
                      
                      <select class="custom-select" name="section"  required id="monitor">
                  <option  value="NULL" >NULL</option>
                  <option value="C" >C</option>
                  <option value="D" >D</option>                            
                             </select>
                             </div>
                                      
                    </div>
                    <div class="form-group row">
                    <div class="col-sm-6">
                        <label for="" class="control-label">Designation</label>
                      
                    <select class="custom-select" name="designation" required id="monitor">
                <option value="<?php echo $row['designation']?>" ><?php echo $row['designation']?></option>
                            
                           </select>
                        
              
                  </div>    
                  <div class="col-sm-6">
                    <label for="inputAddressLine2">Office Shift</label>
                    <Select name="shift" required class="form-control">
                    <option value="<?php echo $row['shift']?>"><?php echo $row['shift']?></option>
                    <option value="Morning Shift">Morning Shift</option>
                    <option value="Full Day Shift">Full Day Shift</option>
                    <option value="Evening Shift">Evening Shift</option>

                </select>
                </div>
                </div>
                
                <div class="form-group row">
                    <div class="col-sm-4">
                        <label for="inputContactNumber">Address</label>
                        <input type="text" class="form-control"value="<?php echo $row['address']?>" name="address" placeholder="address">
                    </div>
                    <div class="col-sm-4">
                        <label for="inputWebsite">Employment Date*</label>
                        <input type="text" class="form-control" value="<?php echo $row['empdate']?>"  name="empdate" >
                    </div>
                    <div class="form-group  col-sm-4">
                     <label>Employee Type</label>
                    <Select name="emptype" class="form-control">
                    <option value="<?php echo $row['emptype']?>"><?php echo $row['emptype']?> </option>
                    <option value="Fixed Contract">Fixed Contract</option>
                    <option value="Internship">Internship</option>
                    <option value="Attachment">Attachment</option>
                    </select>
                  </div>
                </div>
                
                <div class="form-group row">
                    <div class="col-sm-4">
                        <label for="inputContactNumber">Email</label>
                        <input type="email" class="form-control" value="<?php echo $row['email']?>" name="email" placeholder="email">
                    </div>
                    <div class="col-sm-4">
                        <label for="inputWebsite">Contact Number*</label>
                        <input type="text" name="contact" class="form-control" value="<?php echo $row['contact']?>" placeholder="Phone number">
                    </div>
                    <div class="col-sm-4">
                    <label>KRA PIN</label>
                <input type="text" name="pin" value="<?php echo $row['pin']?>" class="form-control" placeholder="KRA PIN">  
                    </div>
                  </div>




            <div class="form-group">
                <label>Password</label>
                <input type="password" name="edit_password" class="form-control" value="<?php echo $row['password']?>" placeholder="Enter Password">
            </div>
            
            <a href="register.php" class="btn btn-danger">CANCEL</a>
            <button type="submit" name="updatebtn" class="btn btn-primary">UPDATE</button>
         </form>
            <?php  
}
}
?>


        </div>
      
</div>
</div>
</div>









<?php
 include('includes/scripts.php');
 include('includes/footer.php');
 
 ?>
