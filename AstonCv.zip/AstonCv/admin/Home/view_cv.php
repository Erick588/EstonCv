<?php 
      
      include('security.php');
      include('includes/header.php');
      include('includes/navbar.php');

?>
<div class="card card-outline card-primary">
		<div class="card-header">
		

<?php
if(isset($_POST['view']))
{
$id = $_POST['vid'];

$query="SELECT c.firstname, c.others, c.user, c.email, a.institution, a.date, a.course, a.duties, a.user_id, a.position, a.grade, a.lang, a.lang1, a.lang2 FROM cvs c 
        LEFT JOIN profile a ON a.user_id = c.email WHERE a.id = '$id'";


$query_run = mysqli_query($connection, $query);

foreach($query_run as $row)
{

    
  ?>
<center>

<div class="" style="width: 18rem;">
  <ul class=" list-inline-item text-center">
    <li class="list-inline-item"><b>Names:</b><?php echo	$meta = $row['firstname']." ".$row['others']; ?></li>
    <br/>
    <li class="list-inline-item"><b>Position: </b><?php echo $meta =$row['position']; ?></li>
    <li class="list-inline-item"><b>Languages#: </b><?php echo $meta =$row['lang']." ,".$row['lang1']." ,".$row['lang2']; ?></li>
   
  </ul>
</div>
</center>
</div>
<div class="card">
<div class="card-body">


	<div class="row">
		<div class="col-md-6">
			<div class="card card-outline card-danger">
				<div class="card-body">
					<div class="">
						<dl class="callout callout-info">
							<dt>Education:</dt>
							<dd><?php echo	$meta = $row['institution']; ?></dd>
							<dt>Start Date#</dt>
							<dd><?php echo date('M d, Y', strtotime($row['date'])); ?></dd>
                            <dt>Course#</dt>
							<dd><?php echo $row['course']; ?></dd>
                            <dt>Grade:</dt>
							<dd><?php echo	$meta = $row['grade']; ?></dd>
						</dl>

					</div>
				</div>
			</div>
		</div>
		<div class="col-md-6">
			
			<div class="card card-outline card-warning">

				<div class="card-header">
                <dl class="callout callout-info">
							<dt>Duties:</dt>
							<dd><?php echo	$meta = $row['duties']; ?></dd>
                                                     
				


			
				</div>
				
				</div>
			</div>
		</div>
	</div>
    <?php  
}
}
?>
</div>
</div>

<?php
 include('includes/scripts.php');
 include('includes/footer.php');
 ?>