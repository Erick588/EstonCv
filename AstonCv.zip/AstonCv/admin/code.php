<?php
session_start();
$connection= mysqli_connect('localhost', 'root', '', 'erp');

if(isset($_POST['registerbtn']))
{
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $cpassword = $_POST['confirmpassword'];
    $usertype = $_POST['usertype'];


    if($password==$cpassword)
    {
    $usertype = $_POST['usertype'];
    $query = "INSERT INTO user1 (username,email,password, usertype) VALUES ('$username','$email','$password','$usertype')";
        $query_run = mysqli_query($connection, $query);
        
        if($query_run)
        {
            echo "Saved";
            $_SESSION['success'] = "Admin Profile Added";
            header('Location: register.php');
           
        }
        else 
        {
            $_SESSION['status'] = "Admin Profile Not Added";
            header('Location: register.php');  
        }

    }
  else{

    $_SESSION['status'] = "Password and Confirm Password does not match";
    header('Location: register.php');  
  }    

}



 
if(isset($_POST['updatebtn'])){
    $id=$_POST['edit_id'];
    $username = $_POST['edit_username'];
    $firstname = $_POST['firstname'];
    $middlename = $_POST['middlename'];
    $lastname = $_POST['lastname'];
    $distatus = $_POST['distatus'];
    $empcode = $_POST['empcode'];
    $idno = $_POST['idno'];
    $birthdate = $_POST['birthdate'];
    $sex = $_POST['sex'];
    $department = $_POST['department'];
    $grade = $_POST['grade'];
    $points = $_POST['points'];
    $division = $_POST['division'];
    $section = $_POST['section'];
    $designation = $_POST['designation'];
    $shift = $_POST['shift'];
    $address = $_POST['address'];
    $empdate = $_POST['empdate'];
    $emptype = $_POST['emptype'];
    $email = $_POST['email'];
    $contact = $_POST['contact'];
    $pin = $_POST['pin']; 
    $password = $_POST['password'];
    $usertype = $_POST['usertype'];


    $distatus = $_POST['distatus'];
$query = "UPDATE user1 SET username='$username', firstname='$firstname', middlename='$middlename',
lastname='$lastname', distatus='$distatus',empcode='$empcode',idno='$idno',birthdate='$birthdate',
sex='$sex',department='$department',division='$division',section='$section',designation='$designation',
shift='$shift' ,address ='$address',empdate='$empdate',emptype='$emptype',
email='$email', contact='$contact', pin='$pin',password='$password',
 usertype='$usertypeupdate' WHERE id='$id' ";

$query_run = mysqli_query($connection, $query);

if($query_run)
{
$_SESSION['success']= "Your Data is Updated";
header('location: register.php');
}
else{
  $_SESSION['status']= "Your Data is Not Updated";
  header('location: register.php');

}
}
if(isset($_POST['logout_btn']))
{
  session_destroy();
  unset($_SESSION['username']);
  header('location:login.php');
}



if(isset($_POST['att_btn'])){
  $emp_id=$_POST['emp_id'];
  $date = $_POST['date'];
  $location = $_POST['location'];
  $time_in = $_POST['time_in'];
  $time_out = $_POST['time_out'];
  $status = $_POST['status'];
  $hrs =  ($time_out - $time_in) - 1 ;
  $overtime = $hrs - 8 ;
  $schedule = $_POST['schedule']; 

$query = "INSERT INTO attendance (emp_id,date,location, time_in, time_out, status, hrs, overtime, schedule) VALUES 
('$emp_id','$date','$location','$time_in','$time_out','$status','$hrs', '$overtime','$schedule')";

$query_run = mysqli_query($connection, $query);

if($query_run)
{
  $_SESSION['success']= "Your Data is Updated";
header('location: attendance.php');
}
else{
  $_SESSION['status']= "Your Data is Not Updated";
  header('location: attendance.php');

}
}




if(isset($_POST['leavebtn'])){
  $user_id=$_POST['user_id'];
  $location= $_POST['location'];
  $ruhusa = $_POST['ruhusa'];
  $srtate = $_POST['srtate'];
  $enddate = $_POST['enddate'];
  $description = $_POST['description'];
  $status = $_POST['status'];


if(strtotime($enddate) > strtotime($srtate)){


$query = "INSERT INTO leaveapp (user_id,location, ruhusa,srtate ,enddate, description, status) VALUES ('$user_id','$location','$ruhusa','$srtate','$enddate','$description','$status')";

$query_run = mysqli_query($connection, $query);

if($query_run)
{
$_SESSION['success']= "Leave Application Successful";
header('location: leave.php');
}
else{
  $_SESSION['status']= "Leave Application Unsuccessful";
  header('location: leave.php');

}
}
else{
  $_SESSION['status']= "End date must be less than Start date";
  header('location: leave.php');

}
}
if(isset($_POST['prombtn'])){

  $user_id=$_POST['user_id'];
  $des = $_POST['des'];
  $promtitle = $_POST['promtitle'];
  $description = $_POST['description'];
  $status = $_POST['status'];
 
  
$query = "INSERT INTO promotions (user_id,des,promtitle, description, status) VALUES 
('$user_id','$des','$promtitle','$description', '$status')";

$query_run = mysqli_query($connection, $query);

if($query_run)
{
  $quey = "UPDATE user1 SET designation= '$promtitle'
   WHERE id= $user_id ";
  $query_run = mysqli_query($connection, $quey);
$_SESSION['success']= "Your Data is Updated";
header('location: promotion.php');
}
else{
  $_SESSION['status']= "Your Data is Not Updated";
  header('location: promotion.php');

}
}

if(isset($_POST['resignationbtn'])){

  $user_id=$_POST['user_id'];
  $notdate = $_POST['notdate'];
  $resdate = $_POST['resdate'];
  $reason = $_POST['reason'];
  $status = $_POST['status'];
  
$query = "INSERT INTO resignation (user_id,notdate,resdate, reason,status) VALUES 
('$user_id','$notdate','$resdate','$reason', '$status')";

$query_run = mysqli_query($connection, $query);

if($query_run)
{
  $quey = "UPDATE user1 SET status= 'Innactive'
  WHERE id= $user_id ";
 $query_run = mysqli_query($connection, $quey);
$_SESSION['success']= "Your Data is Updated";
header('location: resignation.php');
}
else{
  $_SESSION['status']= "Your Data is Not Updated";
  header('location: resignation.php');

}
}

if(isset($_POST['dismissalbtn'])){

  $user_id=$_POST['user_id'];
  $type=$_POST['type'];
  $disdate = $_POST['disdate'];
  $description = $_POST['description'];
  $status = $_POST['status'];
  
  
$query = "INSERT INTO dismissal (user_id,type,disdate,description,status) VALUES
 ('$user_id','$type','$disdate','$description','$status')";

$query_run = mysqli_query($connection, $query);

if($query_run)
{
  $quey = "UPDATE user1 SET status= 'Innactive'
  WHERE id= $user_id ";
 $query_run = mysqli_query($connection, $quey);
$_SESSION['success']= "Your Data is Updated";
header('location: dismissal.php');
}
else{
  $_SESSION['status']= "Your Data is Not Updated";
  header('location: dismissal.php');

}
}

if(isset($_POST['resignationbtn'])){

  $user_id=$_POST['user_id'];
  $notdate = $_POST['notdate'];
  $resdate = $_POST['resdate'];
  $reason = $_POST['reason'];
  $status = $_POST['status'];
  
$query = "INSERT INTO resignation (user_id,notdate,resdate, reason,status) VALUES
 ('$user_id','$notdate','$resdate','$reason', '$status')";

$query_run = mysqli_query($connection, $query);

if($query_run)
{
  $quey = "UPDATE user1 SET status= 'Innactive'
  WHERE id= $user_id ";
 $query_run = mysqli_query($connection, $quey);
$_SESSION['success']= "Your Data is Updated";
header('location: resignation.php');
}
else{
  $_SESSION['status']= "Your Data is Not Updated";
  header('location: resignation.php');

}
}

if(isset($_POST['warningbtn'])){

  $user_id=$_POST['user_id'];
  $warning_by=$_POST['warning_by'];
  $warning = $_POST['warning'];
  $subject = $_POST['subject'];
  $description = $_POST['description'];
  $status = $_POST['status'];

  
  
$query = "INSERT INTO warnings (user_id,warning_by,warning,subject,description,status) VALUES
 ('$user_id','$warning_by','$warning','$subject','$description','$status')";

$query_run = mysqli_query($connection, $query);

if($query_run)
{
$_SESSION['success']= "Your Data is Updated";
header('location: warnings.php');
}
else{
  $_SESSION['status']= "Your Data is Not Updated";
  header('location: warnings.php');

}
}
if(isset($_POST['save_btn'])){

  $description=$_POST['description'];
  $amount=$_POST['amount'];
 

  
  
$query = "INSERT INTO deductions (description,amount) VALUES ('$description','$amount')";

$query_run = mysqli_query($connection, $query);

if($query_run)
{
$_SESSION['success']= "Your Data is Updated";
header('location: deductions.php');
}
else{
  $_SESSION['status']= "Your Data is Not Updated";
  header('location: deductions.php');

}
}

if(isset($_POST['bonus_btn'])){
  $user_id=$_POST['user_id'];
  $deduction=$_POST['deduction'];
  $amount1=$_POST['amount1'];
  $compensation=$_POST['compensation'];
  $amount2=$_POST['amount2'];
  $date=$_POST['date'];
 

  
  
$query = "INSERT INTO remitt (user_id,deduction,amount1,compensation,amount2,date) VALUES ('$user_id','$deduction',
'$amount1','$compensation','$amount2','$date')";

$query_run = mysqli_query($connection, $query);

if($query_run)
{
$_SESSION['success']= "Your Data is Updated";
header('location: compensations.php');
}
else{
  $_SESSION['status']= "Your Data is Not Updated";
  header('location: compensations.php');

}
}


if(isset($_POST['payroll_btn'])){

  $id=$_POST['user_id'];
  $deduction_id=$_POST['deduction_id'];
  $bonuses=$_POST['bonuses'];


$query = "INSERT INTO remit (user_id, deduction_id,bonuses) VALUES ('$id','$deduction_id', '$bonuses')";

$query_run = mysqli_query($connection, $query);

if($query_run)
{
$_SESSION['success']= "Your Data is Updated";
header('location: payroll.php');
}
else{
  $_SESSION['status']= "Your Data is Not Updated";
  header('location: payroll.php');

}
}

if(isset($_POST['bnkcash_btn'])){

  $name=$_POST['name'];
  $bal =$_POST['bal'];
  $acnum =$_POST['acnum'];
  $bchcode =$_POST['bchcode'];
  $bank_branch =$_POST['bank_branch'];



$query = "INSERT INTO bank_cash (name, bal, acnum, bchcode, bank_branch) VALUES ('$name','$bal', '$acnum', '$bchcode', '$bank_branch')";

$query_run = mysqli_query($connection, $query);

if($query_run)
{
$_SESSION['success']= "Your Data is Updated";
header('location: bankcash.php');
}
else{
  $_SESSION['status']= "Your Data is Not Updated";
  header('location: bankcash.php');

}
}

if(isset($_POST['payee_btn'])){

  $name=$_POST['name'];
  $bal =$_POST['bal'];
  $acnum =$_POST['acnum'];
  $bchcode =$_POST['bchcode'];
  $bank_branch =$_POST['bank_branch'];



$query = "INSERT INTO bank_cash (name, bal, acnum, bchcode, bank_branch) VALUES ('$name','$bal', '$acnum', '$bchcode', '$bank_branch')";

$query_run = mysqli_query($connection, $query);

if($query_run)
{
$_SESSION['success']= "Your Data is Updated";
header('location: bankcash.php');
}
else{
  $_SESSION['status']= "Your Data is Not Updated";
  header('location: bankcash.php');

}
}

if(isset($_POST['payeee_btn'])){

  $payee=$_POST['payee'];
  $compname =$_POST['comp_name'];
  $address =$_POST['address'];
  $number =$_POST['number'];

$query = "INSERT INTO payee (payee,compname,address, number) VALUES ('$payee','$compname','$address','$number')";

$query_run = mysqli_query($connection, $query);

if($query_run)
{
$_SESSION['success']= "Your Data is Updated";
header('location: payees.php');
}
else{
  $_SESSION['status']= "Your Data is Not Updated";
  header('location: payees.php');

}
}

if(isset($_POST['payers_btn'])){

  $payer=$_POST['payer'];
  $number =$_POST['number'];

$query = "INSERT INTO payer (payer, number) VALUES ('$payer','$number')";

$query_run = mysqli_query($connection, $query);

if($query_run)
{
$_SESSION['success']= "Your Data is Updated";
header('location: payees.php');
}
else{
  $_SESSION['status']= "Your Data is Not Updated";
  header('location: payees.php');

}
}


if(isset($_POST['deposit_btn'])){

  $bank=$_POST['bank'];
  $description =$_POST['description']; 
  $amount=$_POST['amount'];
  $date=$_POST['date'];
  $filename = $_FILES['deposit_file']['name'];
  $category=$_POST['category'];
  $payer=$_POST['payer'];
  $payment=$_POST['payment'];
  $ref=$_POST['ref'];
  move_uploaded_file($_FILES['deposit_file']['tmp_name'], '../images/'.$filename);	

$query = "INSERT INTO deposit (bank,description,amount,date,deposit_file,category,payer,payment, ref) VALUES ('$bank','$description',
'$amount','$date','$filename','$category','$payer','$payment','$ref')";

$query_run = mysqli_query($connection, $query);

if($query_run)

{
  
  $quey = "UPDATE bank_cash SET bal = bal+ $amount
  WHERE name = '$bank'";
 $query_run = mysqli_query($connection, $quey);

$_SESSION['success']= "Your Data is Updated";
header('location: deposit.php');
}
else{
  $_SESSION['status']= "Your Data is Not Updated";
  header('location: deposit.php');

}
}
if(isset($_POST['expense_btn'])){

  $bank=$_POST['bank'];
  $description =$_POST['description']; 
  $amount=$_POST['amount'];
  $date=$_POST['date'];
  $filename = $_FILES['deposit_file']['name'];
  $category=$_POST['category'];
  $payee=$_POST['payee'];
  $payment=$_POST['payment'];
  $ref=$_POST['ref'];
  move_uploaded_file($_FILES['deposit_file']['tmp_name'], '../images/'.$filename);	

$query = "INSERT INTO expenses (bank,description,amount,date,deposit_file,category,payee,payment, ref) VALUES ('$bank','$description',
'$amount','$date','$filename','$category','$payee','$payment','$ref')";

$query_run = mysqli_query($connection, $query);

if($query_run)

{
  
  $quey = "UPDATE bank_cash SET bal = bal- $amount
  WHERE name = '$bank'";
 $query_run = mysqli_query($connection, $quey);

$_SESSION['success']= "Your Data is Updated";
header('location: new_expense.php');
}
else{
  $_SESSION['status']= "Your Data is Not Updated";
  header('location: new_expense.php');

}
}
if(isset($_POST['transfer_btn'])){

  $from_bank=$_POST['from_bank'];
  $to_bank =$_POST['to_bank']; 
  $description=$_POST['description'];
  $amount=$_POST['amount'];
  $date=$_POST['date'];
  $payment=$_POST['payment'];
  $ref=$_POST['ref'];
  

$query = "INSERT INTO cash_transfer (from_bank, to_bank, description,amount,date,payment, ref) VALUES ('$from_bank','$to_bank','$description',
'$amount','$date','$payment','$ref')";

$query_run = mysqli_query($connection, $query);

if($query_run)

{
  
  $quey = "UPDATE bank_cash  SET bal = bal- $amount 
  WHERE name = '$from_bank'";  
 
 $query_run = mysqli_query($connection, $quey);

 $quy = "UPDATE bank_cash  SET  bal = bal+$amount 
 WHERE name = '$to_bank'"; 

  $query_run = mysqli_query($connection, $quy);
 

$_SESSION['success']= "Your Data is Updated";
header('location: cash_transfer.php');
}
else{
  $_SESSION['status']= "Your Data is Not Updated";
  header('location: cash_transfer.php');

}
}
if(isset($_POST['retirementbtn'])){

  $name =$_POST['name'];
  $notice =$_POST['notice']; 
  $retire=$_POST['retire'];
  $status=$_POST['status'];

  

$query = "INSERT INTO retirement (name, notice, retire, status) VALUES ('$name','$notice','$retire','$status')";

$query_run = mysqli_query($connection, $query);

if($query_run)

{
$_SESSION['success']= "Your Data is Updated";
header('location: retirement.php');
}
else{
  $_SESSION['status']= "Your Data is Not Updated";
  header('location: retirement.php');

}
}

if(isset($_POST['comp_btn'])){

  $user_id= $_POST['user_id'];
  $grade= $_POST['grade']; 
  $points=$_POST['points'];
  $houseall =$_POST['houseall'];
  $commuter =$_POST['commuter'];
  $extraneous =$_POST['extraneous'];
  $entertainment =$_POST['entertainment'];
  $airtime =$_POST['airtime'];
  $gross= $points + $houseall + $commuter + $extraneous + $entertainment + $airtime;
$query = "INSERT INTO salaries (user_id, grade, points, houseall, commuter, extraneous, entertainment, airtime,gross) 
VALUES ('$user_id','$grade','$points','$houseall', '$commuter', 
'$extraneous', '$entertainment', '$airtime','$gross')";

$query_run = mysqli_query($connection, $query);

if($query_run)

{
$_SESSION['success']= "Your Data is Updated";
header('location: compensations1.php');
}
else{
  $_SESSION['status']= "Your Data is Not Updated";
  header('location: compensations1.php');

}
}

if(isset($_POST['budget-btn'])){
  $code= $_POST['code'];
  $finyear= $_POST['fin_year'];
  $type= $_POST['type'];
  $govtgrant= $_POST['govt_grant'];
  $supp_budget =$_POST['supp_budget'];
  $prevrev =$_POST['prev_rev'];
  $otherincomes =$_POST['other_incomes'];
  $total= $govtgrant + $internalrev + $supp_budget + $prevrev;

  $basicsal =$_POST['basic_sal'];
  $houseall =$_POST['house_all']; 
  $ext_all =$_POST['ext_all'];
  $remall =$_POST['rem_all'];
  $transall =$_POST['trans_all'];
  $ent_all =$_POST['ent_all'];
  $leaveall =$_POST['leave_all'];
  $gratuity =$_POST['gratuity'];
  $pensions =$_POST['pensions'];
  $actn_all =$_POST['actn_all'];
  $duty_all =$_POST['duty_all'];
  $nssf= $_POST['nssf'];

  $stakeholders =$_POST['stakeholders'];
  $staffawards =$_POST['staff_awards']; 
  $bank_charges =$_POST['bank_charges']; 
  $staffwelfare =$_POST['staff_welfare'];
  $postage= $_POST['postage'];
  $newpapers= $_POST['newpapers'];
  $csr =$_POST['csr'];
  $tendercost =$_POST['tender_cost'];
  $staffunion =$_POST['staff_union'];
  $isocertifications =$_POST['iso_certifications'];
  $licenses =$_POST['licenses'];
  $auditfees =$_POST['audit_fees'];

  $honorarium =$_POST['honorarium'];
  $sittingall =$_POST['sitting_all'];
  $perdiem =$_POST['perdiem'];
  $lunchall =$_POST['lunch_all'];
  $training =$_POST['training'];
  $travel =$_POST['travel'];
  $mileage =$_POST['mileage'];
  $airtime =$_POST['airtime'];


  $medall =$_POST['med_all'];
  $grouplife =$_POST['group_life'];
  $ict_consult= $_POST['ict_consult'];
  $vehall =$_POST['veh_all'];
  $assets =$_POST['assets']; 
  $pers_accident =$_POST['pers_accident'];
  $cleaning =$_POST['cleaning'];
  $swsupport =$_POST['sw_support'];
  $veh_insurance=$_POST['veh_insurance'];
  $strategicplan =$_POST['strategic_plan'];
  $humanresource =$_POST['human_resource'];
  $asseteva =$_POST['asset_eva'];
  $manuals =$_POST['manuals'];
  $automation =$_POST['automation'];

  $resourcemob =$_POST['resource_mob'];
  $monitoring =$_POST['monitoring'];
  $duc =$_POST['duc'];
  $policyguide =$_POST['policy_guide'];

  $commserv =$_POST['comm_services'];
  $transcosts =$_POST['trans_costs'];
  $officesup =$_POST['office_supplies'];
  $vehrepairs =$_POST['veh_repairs'];
  $print =$_POST['print'];
  $hospitality =$_POST['hospitality'];
  $petroleum =$_POST['petroleum'];
  $airtickets =$_POST['air_tickets'];
  $gtraining =$_POST['gtraining'];
  $officerepairs =$_POST['office_repairs'];
  $ictmaint =$_POST['ict_maint'];
  $tmiserv = $_POST['tmi_services'];
  $furniture =$_POST['furniture'];
  $consultancy =$_POST['consultancy'];
  $localtravel =$_POST['local_travel'];
  $utilitycost =$_POST['utility_cost'];
  $membership =$_POST['membership'];
  $rent =$_POST['rent'];
  $publicity =$_POST['publicity'];
  $legalfees =$_POST['legal_fees'];
  $publicity =$_POST['publicity'];
  $conference =$_POST['conference'];
  $bankcharges =$_POST['bank_charges'];
  $cleaningacc =$_POST['cleaning_accessories'];
  $advertising =$_POST['advertising'];
  $status =$_POST['status'];


  $furniture1 =$_POST['furniture1'];
  $motorveh =$_POST['motor_veh'];
  $itequip =$_POST['it_equip'];
  $storageeq =$_POST['storage_eq'];
  $renovations =$_POST['renovations'];



$query = "INSERT INTO recurrentrev (code, fin_year, type, govt_grant, internal_rev, supp_budget, prev_rev, total, status) 
VALUES ('$code','$finyear', '$type','$govtgrant','$otherincomes','$supp_budget','$prevrev','$total','$status')";

$query_run = mysqli_query($connection, $query);

$qry = "INSERT INTO operatingexpe (code, fin_year, type, basic_sal, house_all, ext_all, rem_all, trans_all, leave_all, gratuity, ent_all, duty_all, actn_all, nssf, pensions, status) 
  VALUES ('$code','$finyear','$type','$basicsal','$houseall','$ext_all','$remall','$transall','$leaveall','$gratuity','$ent_all','$duty_all','$actn_all','$nssf','$pensions','$status')";

$query_run = mysqli_query($connection, $qry);

$qury = "INSERT INTO adminexpe (code,fin_year,type, stakeholders, staff_awards, staff_welfare, postage, newpapers, csr, 
tender_cost, staff_union, iso_certifications, licenses, audit_fees,bank_charges,status) 
  VALUES ('$code','$finyear','$type','$stakeholders','$staffawards',' $staffwelfare','$postage', ' $newpapers', 
  ' $csr', '$tendercost','$staffunion','$isocertifications','$licenses','$auditfees','$bank_charges','$status')";

$query_run = mysqli_query($connection, $qury);


$qy = "INSERT INTO boardexpe (code,fin_year, honorarium, sitting_all, perdiem, lunch_all, training, travel, 
mileage, airtime, status) 
  VALUES ('$code','$finyear','$honorarium','$sittingall','$perdiem','$lunchall','$training', 
  ' $travel','$mileage','$airtime','$status')";

$query_run = mysqli_query($connection, $qy);


$qy = "INSERT INTO contractedserv (code,fin_year, type, med_all, personal_accident, vehicle_insurance, group_life, veh_all, assets, cleaning, sw_support, 
strategic_plan, human_resource, asset_eva, manuals, automation, ict_consult, status) 
  VALUES ('$code','$finyear','$type','$medall','$pers_accident','$veh_insurance','$grouplife','$vehall','$assets','$cleaning', 
  '$swsupport','$strategicplan','$humanresource','$asseteva','$manuals','$automation','$ict_consult','$status')";

$query_run = mysqli_query($connection, $qy);

$qy = "INSERT INTO coremandate (code,fin_year,type, resource_mob, monitoring, duc, policy_guide, status) 
  VALUES ('$code','$finyear','$type','$resourcemob','$monitoring',' $duc','$policyguide','$status')";

$query_run = mysqli_query($connection, $qy);

$qyr = "INSERT INTO goodservices (code, fin_year, type, comm_services, trans_costs, office_supplies, print, hospitality,
 tmi_services, petroleum, ict_maint, furniture, local_travel, air_tickets, training_capacity, utility_cost, advertising, 
 consultancy, membership, rent, legal_fees, publicity, conference
 , bank_charges, cleaning_accessories, office_repairs, veh_repairs, status) 
  VALUES ('$code','$finyear','$type','$commserv','$transcosts','$officesup','$print','$hospitality','$tmiserv',
  '$petroleum','$ictmaint','$furniture','$localtravel','$airtickets','$gtraining','$utilitycost','$advertising','$consultancy',
  '$membership','$rent','$legalfees','$publicity','$conference','$bankcharges','$cleaningacc','$officerepairs','$vehrepairs','$status')";

$query_run = mysqli_query($connection, $qyr);


$qyru = "INSERT INTO capital_expenditure (code,fin_year,type, furniture1, motor_veh, it_equip, storage_eq, renovations, status) 
  VALUES ('$code','$finyear','$type','$furniture1','$motorveh',' $itequip','$storageeq','$renovations','$status')";

$query_run = mysqli_query($connection, $qyru);

if($query_run)

{
  


$_SESSION['success']= "Your Data is Updated";
header('location: budget.php');
}
else{
  $_SESSION['status']= "Your Data is Not Updated";
  header('location: budget.php');

}
}
if(isset($_POST['contract_btn'])){

  $user_id =$_POST['user_id'];
  $action =trim($_POST['action']); 
  $start= $_POST['start_date'];
  $end= $_POST['end_date'];

$query = "INSERT INTO contracts (user_id, action, start_date, end_date) VALUES ('$user_id','$action','$start',
'$end')";
$query_run = mysqli_query($connection, $query);
if($action== 'Terminate'){
  $query_run =  mysqli_query($connection,"update user1 set status = 'Innactive' where id='$user_id'")or die(mysqli_error());
}elseif($action== 'Renew'){
  $query_run =  mysqli_query($connection,"update user1 set status = 'Active' where id='$user_id'")or die(mysqli_error());

}else{
  $query_run =  mysqli_query($connection,"update user1 set status = 'Active' where id='$user_id'")or die(mysqli_error());

}

if($query_run)
{  

$_SESSION['success']= "Your Data is Updated";
header('location: contracts.php');
}
else{
  $_SESSION['status']= "Your Data is Not Updated";
  header('location: contracts.php');

}
}
if(isset($_POST['loan_btn'])){
  $user_id =$_POST['user_id'];
  $sacco =$_POST['sacco']; 
  $principal= $_POST['principal'];
  $installments= $_POST['installments'];
  $rate= $_POST['rate'];
  $months= $_POST['months'];
  $shares= $_POST['shares'];
  $shares_ded= $_POST['shares_ded'];
  $smonths= $_POST['shares_months'];
  $bank= $_POST['bank'];
  $bank_principal= $_POST['bank_principal'];
  $bank_installments= $_POST['bank_installments'];
  $bank_month= $_POST['bank_months'];
  $insuarance= $_POST['insuarance'];
  $type= $_POST['insurance_type'];
  $amount= $_POST['amount'];
  $month1= $_POST['month1'];
  $helb= $_POST['helb'];
  $helb_principal= $_POST['helb_principal'];
  $helb_installments= $_POST['helb_installments'];
  $helb_month= $_POST['helb_months'];


$query = "INSERT INTO loan (name, sacco, principal, principal2, installments, rate, months, bank,
 bank_principal, bank_principal1, bank_installments, bank_month, insuarance, amount, amount1, insurance_type, months1,
  helb, helb_principal, helb_principal1, helb_installments, helb_month, shares, shares_ded, shares_ded1, shares_months) 
VALUES ('$user_id','$sacco','$principal','$principal','$installments','$rate','$months','$bank','$bank_principal',
'$bank_principal','$bank_installments','$bank_month','$insuarance','$amount','$amount','$type','$month1','$helb',
'$helb_principal','$helb_principal','$helb_installments','$helb_month','$shares','$shares_ded','$shares_ded','$smonths')";
$query_run = mysqli_query($connection, $query);

if($query_run)
{  

$_SESSION['success']= "Your Data is Updated";
header('location: loans.php');
}
else{
  $_SESSION['status']= "Your Data is Not Updated";
  header('location: loans.php');

}
}

if(isset($_POST['expense_btn']))
{
   
  $bank = $_POST['bank'];
  $banksub = trim($_POST['banksub']);
  $voucher = $_POST['voucher'];
  $budget = $_POST['budget'];
  $description = $_POST['description'];
  $amount = $_POST['amount'];
  $date = $_POST['date'];
  $payee = $_POST['payee'];
  $expense = $_POST['expense'];
  $payment = $_POST['payment']; 
  $code = $_POST['code'];
  $output=nl2br( $description);
  $userId = $_POST['created_by'];
  $status = $_POST['status'];

  $query = "INSERT INTO expense (budget,voucher,bank,banksub,description,amount,date,payee,expense,payment,code,created_by,status) VALUES 
('$budget','$voucher','$bank','$banksub','$description','$amount','$date','$payee','$expense','$payment','$code','$userId','$status')";

$query_run = mysqli_query($connection, $query);

if($query_run)
{
 
  $_SESSION['success']= "Your Data is Updated";
header('location: expenditure.php');
}
else{
  $_SESSION['status']= "Your Data is Not Updated";
  header('location: expenditure.php');

}
}
?>