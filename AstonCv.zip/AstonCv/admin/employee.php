<?php 
      
      include('security.php');
      include('includes/header.php');
      include('includes/navbar.php');

?>
<link rel="stylesheet" type="text/css" href="print.css" media="print">
    <div class="container">
	<div class="card ">

			<div class="span12"><!--  -->
						<center class="title">
						<h5><b>Employees</b></h5>
						</center>
                           <div card-header>
								<div class="pull-left">
								<button onclick="window.print()" class="btn btn-info"><i class="fa fa-print icon-large"></i> Print</a>
								</div>

								<div class="float-right mr-auto">
								<p><a href="new_employee.php" class="btn btn-success float-left"> <i class="fa fa-plus"></i>&nbsp;Add Employee</a></p>
							    </div>
							</div>
							 
							    <div class="card-body">
							     <table cellpadding="-5" cellspacing="-2" border="-2" class="table  table-bordered table-responsive fixed-table-body" id="datatableid">
							    
                                <thead>
                                    <tr>
									    <th>No#</th>                                 
                                        <th>Name</th>                                 
                                        <th>Company#</th>
										<th>Contact</th>
										<th>Role</th>
										<th class="action">Action</th>		
                                    </tr>
                                </thead>
                                <tbody>
							
								  <?php
					$i = 1;
					$qry = $conn->query("SELECT * FROM assets where status != 'Archive' ");
					while($row= $qry->fetch_assoc()):
					?>
					<tr>
						<th class="text-center"><?php echo $i++ ?></th>
						<td><?php echo ucwords($row['brandname']) ?></td>
						<td><?php echo ucwords($row['serialno']) ?></td>
						<td><?php echo ucwords($row['ram']) ?></td>
						<td><?php echo ucwords($row['diskcapacity']) ?></td>
						<td><?php echo ucwords($row['processortype']) ?></td>
						<td><?php echo ucwords($row['os']) ?></td>
						<td><?php echo ucwords($row['officename']) ?></td>
						<td><?php echo ucwords($row['owner']) ?></td>
						<td><?php echo ucwords($row['year']) ?></td>
						<td><?php echo ucwords($row['added_at']) ?></td>
						<td><?php echo ucwords($row['status']) ?></td>
						<td>
								<?php
							// Check if the type of a variable is integer   
							$x = $row['year'];
							$a = date("Y");
							$k = "Requires replacement";
							$v = "New";

							if($x + 3 <= $a)
							{

							echo $k; 


							}

							else
							{
							echo $v;
							}

							?>
</td>
						</td>

						
						
						<td class="text-center">
		                    <div class="btn-group">
		                       <a href="./index.php?page=view_assets&id=<?php echo $row['id'] ?>" class="btn btn-info btn-flat">
		                          <i class="fas fa-eye"></i>
		                        </a>
		                         
		                         <div class="btn-group">
		                       <a href="./index.php?page=delete_assets&id=<?php echo $row['id'] ?>" class="btn btn-danger btn-flat">
		                          <i class="fas fa-trash"></i>
		                        </a>

		                        </a>
		                     
	                      </div>
						</td>
					</tr>	
				<?php endwhile; ?>
				</tbody>
			</table>
		</div>
	</div>
</div>
                           
                                </tbody>
                            </table>
                        </div>

							
			
			</div>		
			</div>
		</div>
    

			
            <script>
            	$(document).ready(function() {
            	    $('#datatableid').DataTable();
            	} );
            </script>
		</div>
    </div>
    <?php
 include('includes/scripts.php');
 include('includes/footer.php');
 
 ?>
